
import React, { useState } from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';

const equipmentCards = [
  {
    question: 'This machine uses fans to circulate steam for faster, more even cooking. What is it?',
    answer: 'Convection Steamer'
  },
  {
    question: 'Rotates meat slowly near heat for juicy, even roasting.',
    answer: 'Rotisserie'
  },
  {
    question: 'Overhead broiler for browning, melting, and finishing dishes.',
    answer: 'Salamander'
  },
  {
    question: 'Large kettle with steam between layers for soups and sauces.',
    answer: 'Steam-Jacketed Kettle'
  }
];

const challengeCards = [
  {
    question: 'Which equipment is used to quickly brown or glaze foods?',
    choices: ['Rotisserie', 'Salamander', 'Charbroiler'],
    answer: 'Salamander'
  },
  {
    question: 'Which equipment uses pressure to steam food quickly?',
    choices: ['Steamer', 'Convection Steamer', 'Pressure Steamer'],
    answer: 'Pressure Steamer'
  },
  {
    question: 'Which machine rotates food to baste it naturally while cooking?',
    choices: ['Rotisserie', 'Hotel Broiler', 'Pressure Steamer'],
    answer: 'Rotisserie'
  }
];

function App() {
  const [card, setCard] = useState(null);

  const drawCard = () => {
    const allCards = [...equipmentCards, ...challengeCards];
    const random = allCards[Math.floor(Math.random() * allCards.length)];
    setCard(random);
  };

  return (
    <div className="game-container">
      <h1>Kitchen Equipment Quest</h1>
      <button onClick={drawCard}>Draw a Card</button>
      {card && (
        <div className="card">
          <p><strong>Question:</strong> {card.question}</p>
          {'choices' in card && (
            <ul>
              {card.choices.map((choice, idx) => (
                <li key={idx}>{choice}</li>
              ))}
            </ul>
          )}
          <p><strong>Answer:</strong> {card.answer}</p>
        </div>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
