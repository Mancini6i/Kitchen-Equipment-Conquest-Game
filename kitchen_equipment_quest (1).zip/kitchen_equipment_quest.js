
import React, { useState } from 'react';
import './index.css';

const equipmentCards = [
  {
    question: 'This machine uses fans to circulate steam for faster, more even cooking. What is it?',
    answer: 'Convection Steamer'
  },
  {
    question: 'Rotates meat slowly near heat for juicy, even roasting.',
    answer: 'Rotisserie'
  },
  {
    question: 'Overhead broiler for browning, melting, and finishing dishes.',
    answer: 'Salamander'
  },
  {
    question: 'Large kettle with steam between layers for soups and sauces.',
    answer: 'Steam-Jacketed Kettle'
  }
];

const challengeCards = [
  {
    question: 'Which equipment is used to quickly brown or glaze foods?',
    choices: ['Rotisserie', 'Salamander', 'Charbroiler'],
    answer: 'Salamander'
  },
  {
    question: 'Which equipment uses pressure to steam food quickly?',
    choices: ['Steamer', 'Convection Steamer', 'Pressure Steamer'],
    answer: 'Pressure Steamer'
  },
  {
    question: 'Which machine rotates food to baste it naturally while cooking?',
    choices: ['Rotisserie', 'Hotel Broiler', 'Pressure Steamer'],
    answer: 'Rotisserie'
  }
];
